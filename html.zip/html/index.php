<?php
$nombrePrograma="Include y menú";
include("header.php");
?>

<?php include("footer.php");?>
