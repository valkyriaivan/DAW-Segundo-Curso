<?php
$nombrePrograma="Formulario";
include("../header.php");
?>
<?php

function test_input($data) {
	$data = trim($data);
	//Quitar las comillas escapadas \' y \ ""
	$data = stripslashes($data);
	//Prevenir la introducción de scripts en los campos
	$data = htmlspecialchars($data);
	return $data;
}
//Inicializar variables
$nombre = $correo = "";
$error = false;
$errores = array();
$emailErr = $nombreErr = false;
//Comprobar tipo de petición
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = test_input($_POST["nombre"]);
    if ($nombre == ""){
        array_push($errores, "Introduce un nombre");
        $nombreErr = true;
    }

    $correo = test_input($_POST["correo"]);
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        array_push($errores, "Formato inválido de correo");
        $emailErr = true;
    }
    if(isset($_FILES['avatar'])){
      if ($_FILES['avatar']['error'] == UPLOAD_ERR_OK){
        $partesFichero = explode('.',$_FILES['avatar']['name']);
        $file_ext=strtolower(end($partesFichero));

        $extensions= array("jpeg","jpg","png");

        if(in_array($file_ext,$extensions)== false){
         array_push($errores, "Extensión no permitida, sólo son válidos archivos jpg o png");
         $error = true;
        }
      }
      else{
        array_push($errores, "No has seleccionado un avatar. Sube una imágen.");
        $error = true;
      }
    }

    if (sizeOf($errores) > 0)
        $error = true;
    if (!$error){
      $file_tmp = $_FILES['avatar']['tmp_name'];
      move_uploaded_file($file_tmp,"avatar/". $_FILES['avatar']['name']);
      $imgAvatar = $_FILES['avatar']['name'];
      echo "<h4>Ha introducido los siguientes datos</h4>";
      echo "<div>Nombre: $nombre<br>";
      echo "Correo: $correo<br>";
      echo "<img src='avatar/$imgAvatar'><br>";
      echo "Enviar otro <a href='" . htmlspecialchars($_SERVER['PHP_SELF']) . "'>mensaje</a><br></div>";
    }

}

if (($_SERVER["REQUEST_METHOD"] == "GET") || $error){
    if ($error){
        //Mostrar todos los mensajes de error
        for ($i = 0; $i < sizeOf($errores); $i++)
            echo "<div class='alert alert-danger' role='alert'>$errores[$i]</div>";
    }
?>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" enctype = "multipart/form-data">
	<div class="form-group <?php if ($nombreErr) echo 'has-error';?>">
    	<label for="nombre">Nombre</label>
    	<input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre completo" value="<?php echo $nombre?>">
	</div>
	<div class="form-group <?php if ($emailErr) echo 'has-error';?>">
    	<label for="correo">Correo</label>
    	<input type="text" class="form-control" id="correo" name="correo"  placeholder="Introduce tu correo electrónico" value="<?php echo $correo?>">
	</div>
	<input type = "file" name ="avatar" accept="image/*">
	<button type="submit" class="btn btn-default">Enviar</button>
</form>
<?php
}
?>
<?php include("../footer.php");?>
