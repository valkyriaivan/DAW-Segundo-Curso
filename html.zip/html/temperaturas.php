<?php
$nombrePrograma="ITemperaturas";
include("header.php");
?>
<?php
//Devuelve un string con temperaturas aleatorias separadas por ','
function rellenaTemperaturas(){
	$temperaturas = "";
	for ($i = 0; $i < 30; $i++){
		$temperaturas .= rand(20, 40) . ",";
	}
	return substr($temperaturas,0, strlen($temperaturas)-1);
}

$temperaturasMensuales = rellenaTemperaturas();

$arrayTem = explode(",", $temperaturasMensuales);
$sumaTem = 0;
foreach ($arrayTem as $temperatura) {
	$sumaTem+=$temperatura;
}
$media = $sumaTem / count($arrayTem);
echo "La media de temperaturas es: <br>";
echo number_format($media, 2, ',', '.') . "º<br>";

sort($arrayTem);

echo "Las 5 menores temperaturas: <br>";
for($i=0;$i<5;$i++){
	if($i==0){
		echo $arrayTem[$i];
	}
	else{
		echo ", " . $arrayTem[$i];
	}
}
echo "<br>Las 5 mayores temperaturas: <br>";
for($i=(count($arrayTem)-1);$i>(count($arrayTem) - 6);$i--){
	if($i==count($arrayTem)-1){
		echo $arrayTem[$i];
	}
	else{
		echo ", " . $arrayTem[$i];
	}
}
echo "<br>";

?>
<?php include("footer.php");?>
