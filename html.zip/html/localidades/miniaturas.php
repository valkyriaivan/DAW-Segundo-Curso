<?php
$nombrePrograma="Miniaturas";
include("../header.php");
?>
<?php

  $dir = "./imagenes";
  $actualPath = getcwd();
  echo $actualPath;
  // Abre un directorio conocido, y procede a leer el contenido
  if (is_dir($dir)) {
      if ($dh = opendir($dir)) {
          while (($file = readdir($dh)) !== false) {
          if (($file != "thumbs") && ( $file != ".") && ($file != ".."))
            $nombreArchio = $actualPath . "/imagenes/thumbs/" . $file;
            if (file_exists($nombreArchio)){
              echo "Extensión: " . $file . " --> " . pathinfo($file, PATHINFO_EXTENSION) . "<a href='$nombreArchio'>";
            }
            else{
              system("convert -sample 256x256 origen $nombreArchio")
            }

          }
          closedir($dh);
      }
  }
?>
<?php include("../footer.php");?>
