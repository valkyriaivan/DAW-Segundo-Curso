<?php
$nombrePrograma="Localidades";
include("../header.php");
?>
<?php
  $localidades = array(
  	'Castellón' =>
  		array('Web'=>'http://www.castello.es',
  			  'Descripcion' => 'Página web del Ayuntamiento de Castellón',
  			  'Foto' => 'castellon.jpg'),
  	'Benicassim' =>
  		array('Web'=>'http://ayto.benicassim.es/',
  			  'Descripcion' => 'Página web del Ayuntamiento de Castellón',
  			  'Foto' => 'benicassim.jpg'),
  	'Burriana' =>
  		array('Web'=>'http://www.burriana.es/',
  			  'Descripcion' => 'Página web del Ayuntamiento de Burriana',
  			  'Foto' => 'burriana.jpg'),
  	'Morella' =>
  		array('Web'=>'http://www.morella.net/',
  			  'Descripcion' => 'Página web del Ayuntamiento de Morella',
  			  'Foto' => 'morella.jpg'),

  	'Peñíscola' =>
  		array('Web'=>'http://www.peniscola.org/',
  			  'Descripcion' => 'Página web del Ayuntamiento de Peñíscola',
  			  'Foto' => 'peniscola.jpg'),

  );
  if (isset($_GET["id"])){
    $id = $_GET["id"];
    if ($id < 1){
      $id = 1;
    }
    elseif ($id > count($localidades)){
      $id=count($localidades);
    }
  }
  else{
    $id = 1;
  }

  $idAr = $id - 1;
  $localidadesNew=array_slice($localidades, $idAr, true);
  foreach ($localidadesNew as $key => $value) {
    echo "<h1>$key</h1>";
    foreach ($value as $key => $value) {
      if ($key == "Web"){
        echo "<a href='$value'>$value</a><br>";
      }
      elseif ($key == "Descripcion"){
        echo "<p><b>$key:</b> $value</p><br>";
      }
      else{
         echo "<img src='imagenes/$value'><br>";
      }
    }
  }
  $url=strtok($_SERVER["REQUEST_URI"],'?');
  $idIni = 1;
  $idSig = $id + 1;
  $idAnt = $id - 1;
  $idUlt = count($localidades);

  echo "<ul class='pagination'>";
  if ($id == 1){
    echo "<li class='disabled'><a href='#'><span>Primero</span></a></li>";
  	echo "<li class='disabled'><a href='#'><span>Anterior</span></a></li>";
  	echo "<li><a href='$url?id=$idSig'><span>Siguiente</span></a></li>";
  	echo "<li><a href='$url?id=$idUlt'><span>Último</span></a></li>";
  }
  elseif ($id > 1 && $id < $idUlt){
    echo "<li><a href='$url?id=$idIni'><span>Primero</span></a></li>";
  	echo "<li><a href='$url?id=$idAnt'><span>Anterior</span></a></li>";
  	echo "<li><a href='$url?id=$idSig'><span>Siguiente</span></a></li>";
  	echo "<li><a href='$url?id=$idUlt'><span>Último</span></a></li>";
  }
  else{
    echo "<li><a href='$url?id=$idIni'><span>Primero</span></a></li>";
  	echo "<li><a href='$url?id=$idAnt'><span>Anterior</span></a></li>";
  	echo "<li class='disabled'><a href='#'><span>Siguiente</span></a></li>";
  	echo "<li class='disabled'><a href='#'><span>Último</span></a></li>";
  }
  echo "</ul><br>";
?>
<?php include("../footer.php");?>
