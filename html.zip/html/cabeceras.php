<?php
  $nombrePrograma="Cabeceras";
  include("header.php");
?>
<?php
  $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
  if ($lang == "en"){
    echo "<p>This webpage is in English.<p>";
  }
  elseif ($lang == "es"){
    echo "<p>Esta web está en ESpañol.</p>";
  }
  else{
    echo "<p>Esta web, por defecto, estará en Español.</p>";
  }
  $agent = $_SERVER['HTTP_USER_AGENT'];
  if(strlen(strstr($agent,"Firefox")) > 0 ){
    echo "Haces bien en usar Firefox <br>";
  }

?>

<?php include("footer.php");?>
